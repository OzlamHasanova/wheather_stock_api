# wheather-stock-api
 It presents accurate and updated weather forecast according to the city name
