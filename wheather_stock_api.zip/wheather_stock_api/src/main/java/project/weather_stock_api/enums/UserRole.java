package project.weather_stock_api.enums;

public enum UserRole {
    USER,ADMIN;
}
