package project.weather_stock_api.exception;

public final class ExceptionConstants {

    public static final Integer INVALID_REQUEST_DATA=100;
    public static final Integer WEATHER_INFORMATION_NOTE_FOUND=101;

}
