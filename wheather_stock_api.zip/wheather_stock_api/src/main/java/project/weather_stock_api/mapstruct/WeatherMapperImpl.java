//package project.weather_stock_api.mapstruct;
//
//import project.weather_stock_api.dto.response.WeatherDto;
//import project.weather_stock_api.dto.response.WeatherResponse;
//import project.weather_stock_api.entity.Weather;
//
//public class WeatherMapperImpl implements WeatherMapper {
//    @Override
//    public Weather mapToWeather(String city, WeatherResponse weatherResponse) {
//        return null;
//    }
//
//    @Override
//    public WeatherDto mapToWeatherDto(Weather weather) {
//        return null;
//    }
//}
